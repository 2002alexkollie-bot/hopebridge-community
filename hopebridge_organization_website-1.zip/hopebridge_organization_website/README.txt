HOPEBRIDGE COMMUNITY INITIATIVE — DEMO WEBSITE

This is a ready-to-preview responsive website template created as a demonstration.
The organization name and all organizational claims are fictional/sample content.
Do not publish as a real organization until you replace:
- Organization name, mission, programs, impact statements, and stories
- Contact email and location
- Images, if you have your own approved photographs
- Any sample numbers with verified information

Preview:
Open index.html in a modern browser. An internet connection is needed for Google Fonts and the remote Unsplash photos.

Publish for free:
1. Extract the ZIP file.
2. Create a GitHub account and a new public repository.
3. Upload index.html, styles.css, and script.js to the repository root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and / (root), then Save.
6. GitHub will show the public website address after it finishes publishing.

Alternative: upload these files to any static web hosting provider. No backend or database is required.
